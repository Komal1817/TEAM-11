<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible"
    content="IE=edge">
        <meta name="viewport"
    content="width=device-width,initial-scale=1">
        <title>Tables</title>
        <link href="css/bootstrap.min.css"
              rel="stylesheet">
              <style>
        
    </style
        <head/>
    <body>
        <div class="container-fluid">
        <table class="table">
            <tr><th>Phone maker</th><th>Model</th><th>storage</th></tr>
            <tr><td>Apple</td><td>Iphone11</td><td>32</td></tr>
            <tr><td>Samsung</td><td>Android</td><td>37</td></tr>
            <tr><td>Oneplus</td><td>Android1.0</td><td>40</td></tr>
            </table>
        
        <table class="table table-striped table-hover table-condenesed table-bordered">
                  <tr><th>Phone maker</th><th>Model</th><th>storage</th></tr>
            <tr><td>Apple</td><td>Iphone11</td><td>32</td></tr>
            <tr><td>Samsung</td><td>Android</td><td>37</td></tr>
            <tr><td>Oneplus</td><td>Android1.0</td><td>40</td></tr>
            </table>